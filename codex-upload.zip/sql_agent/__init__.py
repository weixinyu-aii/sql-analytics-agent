"""SQL analytics agent application."""

